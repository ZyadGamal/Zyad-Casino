<?php
require_once __DIR__ . '/../includes/admin_auth.php';
require_once __DIR__ . '/../includes/admin_functions.php';

$pageTitle = "إدارة المستخدمين";
$activeNav = "users";

// جلب بيانات المستخدمين
$db = Database::getInstance();
$users = $db->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();

// تحميل واجهة المستخدم المحددة
$uiTheme = defined('UI_THEME') ? UI_THEME : 'adminlte';
$uiPath = __DIR__ . "/../assets/src/ui/{$uiTheme}/admin/users.php";

if (file_exists($uiPath)) {
    include $uiPath;
} else {
    include __DIR__ . "/../assets/src/ui/adminlte/admin/users.php";
}