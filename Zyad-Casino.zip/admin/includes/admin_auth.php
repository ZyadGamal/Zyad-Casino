<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/session_manager.php';

// التحقق من صلاحيات المدير
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: /public/login.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

// تعيين إعدادات واجهة المستخدم للمدير
$uiTheme = $_SESSION['admin_ui_theme'] ?? defined('UI_THEME') ? UI_THEME : 'adminlte';
$uiDirection = $_SESSION['admin_ui_direction'] ?? defined('UI_DIRECTION') ? UI_DIRECTION : 'rtl';

// تحميل أصول واجهة المستخدم
$uiAssets = loadUiAssets($uiTheme);