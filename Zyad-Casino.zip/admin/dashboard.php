<?php
require '../config.php';

if (!is_logged_in()) {
    redirect('../index.php');
}

// تسجيل وقت آخر نشاط
$_SESSION['last_activity'] = time();

// التحقق من انتهاء الجلسة بعد 30 دقيقة من عدم النشاط
$inactive = 1800; // 30 دقيقة بالثواني
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $inactive)) {
    session_unset();
    session_destroy();
    redirect('../index.php');
}

// تحديث وقت النشاط مع كل طلب
$_SESSION['last_activity'] = time();

// الحصول على معلومات المستخدم
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user) {
    session_unset();
    session_destroy();
    redirect('../index.php');
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
      <!-- روابط CSS -->
    <link rel="stylesheet" href="../assets/css/admin.css">
    
    <!-- روابط JavaScript -->
    <script src="../assets/js/admin.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- الشريط الجانبي -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-tachometer-alt"></i> لوحة التحكم</h2>
            </div>
            <div class="sidebar-menu">
                <ul>
                    <li class="active"><a href="dashboard.php"><i class="fas fa-home"></i> الرئيسية</a></li>
                    <li><a href="profile.php"><i class="fas fa-user"></i> الملف الشخصي</a></li>
                    <?php if (is_admin()): ?>
                        <li><a href="users.php"><i class="fas fa-users"></i> إدارة المستخدمين</a></li>
                        <li><a href="settings.php"><i class="fas fa-cog"></i> الإعدادات</a></li>
                    <?php endif; ?>
                    <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a></li>
                </ul>
            </div>
        </div>

        <!-- المحتوى الرئيسي -->
        <div class="main-content">
            <div class="top-bar">
                <div class="search-box">
                    <input type="text" placeholder="بحث...">
                    <button><i class="fas fa-search"></i></button>
                </div>
                <div class="user-info">
                    <span><?php echo htmlspecialchars($user['username']); ?></span>
                    <img src="../assets/images/default-avatar.png" alt="صورة المستخدم">
                </div>
            </div>

            <div class="content">
                <h1><i class="fas fa-home"></i> الرئيسية</h1>
                <div class="stats-cards">
                    <div class="card">
                        <div class="card-icon blue">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="card-info">
                            <h3>المستخدمين</h3>
                            <p>150</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-icon green">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="card-info">
                            <h3>الزيارات</h3>
                            <p>2,450</p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-icon orange">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div class="card-info">
                            <h3>المبيعات</h3>
                            <p>320</p>
                        </div>
                    </div>
                </div>

                <div class="recent-activity">
                    <h2><i class="fas fa-clock"></i> النشاط الأخير</h2>
                    <ul>
                        <li>
                            <i class="fas fa-user-circle"></i>
                            <p>تم تسجيل دخول جديد من عنوان IP: <?php echo $_SERVER['REMOTE_ADDR']; ?></p>
                            <span>اليوم، <?php echo date('H:i'); ?></span>
                        </li>
                        <!-- يمكن إضافة المزيد من عناصر النشاط هنا -->
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/admin.js"></script>
</body>
</html>