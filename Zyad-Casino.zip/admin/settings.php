<?php
require_once __DIR__ . '/../includes/admin_auth.php';
require_once __DIR__ . '/../includes/admin_functions.php';

$pageTitle = "إعدادات النظام";
$activeNav = "settings";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // معالجة تحديث الإعدادات
    $theme = $_POST['ui_theme'] ?? 'adminlte';
    $direction = $_POST['ui_direction'] ?? 'rtl';
    
    // تحديث ملف env.php
    updateEnvSettings([
        'UI_THEME' => $theme,
        'UI_DIRECTION' => $direction
    ]);
    
    $_SESSION['success_message'] = "تم تحديث الإعدادات بنجاح";
    header("Location: settings.php");
    exit;
}

// تحميل واجهة المستخدم المحددة
$uiTheme = defined('UI_THEME') ? UI_THEME : 'adminlte';
$uiPath = __DIR__ . "/../assets/src/ui/{$uiTheme}/admin/settings.php";

if (file_exists($uiPath)) {
    include $uiPath;
} else {
    include __DIR__ . "/../assets/src/ui/adminlte/admin/settings.php";
}