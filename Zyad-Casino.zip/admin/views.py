from flask import Blueprint, render_template, jsonify
from flask_jwt_extended import jwt_required
from middleware.auth import admin_required
from models.user import User
from models.security import SuspiciousActivity
from models.payment import Transaction

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/dashboard')
@jwt_required()
@admin_required
def admin_dashboard():
    """لوحة تحكم المشرف"""
    stats = {
        'total_users': User.query.count(),
        'active_users': User.query.filter_by(is_active=True).count(),
        'suspicious_activities': SuspiciousActivity.query.filter_by(resolved=False).count(),
        'recent_transactions': Transaction.query.order_by(Transaction.timestamp.desc()).limit(10).all()
    }
    return render_template('admin/dashboard.html', stats=stats)

@admin_bp.route('/users')
@jwt_required()
@admin_required
def manage_users():
    """إدارة المستخدمين"""
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin/users.html', users=users)

@admin_bp.route('/security/alerts')
@jwt_required()
@admin_required
def security_alerts():
    """تنبيهات الأمان"""
    alerts = SuspiciousActivity.query.order_by(
        SuspiciousActivity.timestamp.desc()
    ).limit(50).all()
    return render_template('admin/security_alerts.html', alerts=alerts)

@admin_bp.route('/system/performance')
@jwt_required()
@admin_required
def system_performance():
    """أداء النظام"""
    metrics = ServerMetrics.query.order_by(
        ServerMetrics.timestamp.desc()
    ).limit(120).all()  # آخر ساعتين بدقيقة لكل نقطة
    return render_template('admin/performance.html', metrics=metrics)