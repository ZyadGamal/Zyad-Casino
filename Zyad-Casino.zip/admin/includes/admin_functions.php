<?php
function updateEnvSettings($settings) {
    $envPath = __DIR__ . '/../config/env.php';
    $envContent = file_get_contents($envPath);
    
    foreach ($settings as $key => $value) {
        $pattern = "/define\('{$key}',\s*'.*?'\);/";
        $replacement = "define('{$key}', '{$value}');";
        $envContent = preg_replace($pattern, $replacement, $envContent);
    }
    
    file_put_contents($envPath, $envContent);
}

function getUiThemes() {
    return [
        'adminlte' => 'AdminLTE',
        'tabler' => 'Tabler',
        'coreui' => 'CoreUI'
    ];
}

function loadUiAssets($theme) {
    $assets = [];
    
    switch ($theme) {
        case 'tabler':
            $assets['css'] = [
                '/assets/compiled/css/tabler.min.css',
                '/assets/compiled/css/tabler-rtl.min.css'
            ];
            $assets['js'] = [
                '/assets/compiled/js/tabler.min.js'
            ];
            break;
            
        case 'coreui':
            $assets['css'] = [
                '/assets/compiled/css/coreui.min.css',
                '/assets/compiled/css/coreui-rtl.min.css'
            ];
            $assets['js'] = [
                '/assets/compiled/js/coreui.min.js'
            ];
            break;
            
        case 'adminlte':
        default:
            $assets['css'] = [
                '/assets/compiled/css/adminlte.min.css',
                '/assets/compiled/css/adminlte-rtl.min.css'
            ];
            $assets['js'] = [
                '/assets/compiled/js/adminlte.min.js'
            ];
    }
    
    return $assets;
}